const Discord = require("discord.js")
const { ActivityType } = require('discord.js');
const config = require("./config.json")
const { QuickDB } = require("quick.db")
const db = new QuickDB()
const { JsonDatabase, } = require("wio.db");

const client = new Discord.Client({ 
  intents: [ 
Discord.GatewayIntentBits.Guilds,
Discord.GatewayIntentBits.GuildMessages,
Discord.GatewayIntentBits.MessageContent,
Discord.GatewayIntentBits.GuildMembers,
'32767'
       ]
    });

module.exports = client

client.on('interactionCreate', (interaction) => {

  if(interaction.type === Discord.InteractionType.ApplicationCommand){

      const cmd = client.slashCommands.get(interaction.commandName);

      if (!cmd) return interaction.reply(`Error`);

      interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);
      
      try {
      cmd.run(client, interaction)
      } catch (error) {
      return interaction.reply({ content: `Ocorreu um erro ao executar o comando.`, ephemeral: true })
      }
   }
});

client.slashCommands = new Discord.Collection()

require('./Handler')(client)

client.login(config.token)

process.on('unhandledRejection', (reason, promise) => {
  console.log(`🚫 Erro Detectado:\n\n${reason.stack}`);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`🚫 Erro Detectado:]\n\n${error.stack}`);
});

process.on('uncaughtExceptionMonitor', (error, origin) => {
  console.log(`🚫 Erro Detectado:\n\n${error.stack}`);
});

client.on('ready', require('./Eventos/FunctionReady').run)
client.on('interactionCreate', require('./Eventos/FunctionEmbed').run)
client.on('interactionCreate', require('./Eventos/ConfigBot').run)
client.on('guildMemberAdd', require('./Eventos/MembroAdd').run)