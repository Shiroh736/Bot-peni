const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder } = require("discord.js");
const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./DatabaseJson/ConfigsEmbed.json" });
const config = new JsonDatabase({ databasePath: "./config.json" });

module.exports = {
  name: "interactionCreate",
  run: async(interaction, client) => {
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("nome_modal")) {
      const novo = interaction.fields.getTextInputValue('novo')
      
      interaction.client.user.setUsername(novo)
      config.set(`configs.name`, novo)
      interaction.reply({ content: `✅ | Nome do BOT alterado!`, ephemeral: true })
      
      puxarembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("avatar_modal")) {
      const novo = interaction.fields.getTextInputValue('novo')
      
      const url = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
      
      if (url.test(novo)) {
        interaction.client.user.setAvatar(novo)
        interaction.reply({ content: `✅ | Avatar do BOT alterado!`, ephemeral: true })
      } else {
        interaction.reply({ content: ":x: | Você inseriu um avatar inválido.", ephemeral: true })
      }
      
      puxarembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("cor_modal")) {
      const novo = interaction.fields.getTextInputValue('novo')
      
      const hex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/
      
      if (hex.test(novo)) {
        config.set(`configs.corbot`, novo)
        interaction.reply({ content: `✅ | Cor do BOT alterado!`, ephemeral: true })
      } else {
        interaction.reply({ content: ":x: | Você inseriu uma cor HEX inválida.", ephemeral: true })
      }
      
      puxarembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("canal_modal")) {
      const novo = interaction.fields.getTextInputValue('novo')
      
      const canal = interaction.guild.channels.cache.get(novo)
      
      if (!canal) return interaction.reply({ content: `:x: | Canal não existe no servidor.`, ephemeral: true })
      
      config.set(`canais.boas_vinda`, novo)
      interaction.reply({ content: `✅ | Canal de Boas Vindas alterado!`, ephemeral: true })
      
      puxarembed()
    }
    
    
    async function puxarembed() {
      const embed = new EmbedBuilder() 
     .setTitle(`${config.get('configs.name') == null ? interaction.guild.name : config.get('configs.name')} | Configurações`)
     .setDescription(`Nome do BOT: ${interaction.client.user.username}\nAvatar do BOT: [Abrir Avatar](${interaction.client.user.displayAvatarURL()})\nCor padrão: ${config.get(`configs.corbot`) == null ? `\`Não definido\`` : config.get(`configs.corbot`)}\nCanal de Boas Vindas: ${interaction.guild.channels.cache.get(config.get(`canais.boas_vinda`)) || "\`Não configurado\`"}`)
     .setColor(config.get('color'))
     
     interaction.message.edit({ embeds: [embed] })
    }
  }
}