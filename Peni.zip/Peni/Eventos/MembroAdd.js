const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder } = require("discord.js");
const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./DatabaseJson/ConfigsEmbed.json" });
const config = new JsonDatabase({ databasePath: "./config.json" });
const colors = require('colors')

module.exports = {
  name: "guildMemberAdd",
  run: async(interaction, member, client) => {
    const channel = interaction.guild.channels.cache.get(config.get(`canais.boas_vinda`))
    
    const user = interaction.user
    
    if (!channel) return console.log(`${colors.red(`Canal de boas vindas mal configurado.`)}`);
    
   let desc = db.get(`desc`)
   desc = desc.replace("{user}", `${user}`)
   desc = desc.replace("{username}", `${interaction.user.username}`)
   desc = desc.replace("{userid}", `${interaction.user.id}`)
   desc = desc.replace("{guildid}", `${interaction.guild.id}`)
   desc = desc.replace("{guildname}", `${interaction.guild.name}`)
   desc = desc.replace("{membros}", `${interaction.guild.memberCount}`)
   
   const embed = new EmbedBuilder()
    .setTitle(`${db.get(`titulo`) == null ? `${interaction.guild.name} | Bem-Vindo` : db.get(`titulo`)}`)
    .setDescription(`${desc}`)
    .setColor(db.get(`color`))
    
    if (db.get(`banner`) == "") {
      
    } else {
      embed.setImage(db.get(`banner`))
    }
    
    if (db.get(`thumb`) == "") {
      
    } else {
      embed.setThumbnail(db.get(`thumb`))
    }
    channel.send({ embeds: [embed] })
  }
}