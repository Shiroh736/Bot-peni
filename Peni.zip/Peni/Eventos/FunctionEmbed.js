const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder } = require("discord.js");
const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./DatabaseJson/ConfigsEmbed.json" });
const config = new JsonDatabase({ databasePath: "./config.json" });

module.exports = {
  name: "interactionCreate",
  run: async(interaction, client) => {
    
    if (interaction.isButton() && interaction.customId.endsWith("alt_titulo")) {
       const modal = new ModalBuilder()
        .setCustomId('modal_titulo')
        .setTitle('Alterar Titulo')
        
       const aaaa = new TextInputBuilder()
        .setCustomId('novo')
        .setLabel('QUAL NOVO TITULO?')
        .setRequired(true)
        .setStyle(1)
        
       modal.addComponents(new ActionRowBuilder().addComponents(aaaa))
       
       return interaction.showModal(modal);
    }
    
    if (interaction.isButton() && interaction.customId.endsWith("alt_desc")) {
      interaction.deferUpdate()
      
       interaction.message.edit({
          embeds: [new EmbedBuilder()
             .setTitle(`${config.get('configs.name') == null ? interaction.guild.name : config.get('configs.name')} | Personalizar Embed`)
             .setDescription(`Envie a nova descrição da embed abaixo:\n\nVocê pode utilizar as strings:\n{user}\n{username}\n{userid}\n{guildid}\n{guildname}\n{membros}\n\nCaso queira cancelar escreva **cancelar**`)
             .setColor(config.get('color'))
           ],
          components: []
       }).then((msg) => {
         
        const collectorFilter = response => {
          return response.author.id === interaction.user.id;
        };
        interaction.channel.awaitMessages({ filter: collectorFilter, max: 1, time: 300000, errors: ['time'] })
        .then(async colleted => {
          const receivedMessage = colleted.first();
          receivedMessage.delete()
           
           if (receivedMessage.content == 'cancelar') {
             
           } else {
             interaction.channel.send({ embeds: [], components: [], content: "✅ Descrição da embed alterado com sucesso." }).then(msga => {setTimeout(() => {msga.delete()}, 4000)})
             db.set(`desc`, receivedMessage.content)
           }
          
          attembed() 
        })
       })
    }
    
    if (interaction.isButton() && interaction.customId.endsWith("alt_cor")) {
       const modal = new ModalBuilder()
        .setCustomId('modal_color')
        .setTitle('Alterar Cor')
        
       const aaaa = new TextInputBuilder()
        .setCustomId('novo')
        .setLabel('QUAL A NOVA COR?')
        .setRequired(true)
        .setStyle(1)
        
       modal.addComponents(new ActionRowBuilder().addComponents(aaaa))
       
       return interaction.showModal(modal);
    }
    
    if (interaction.isButton() && interaction.customId.endsWith("alt_banner")) {
       const modal = new ModalBuilder()
        .setCustomId('modal_banner')
        .setTitle('Alterar Banner')
        
       const aaaa = new TextInputBuilder()
        .setCustomId('novo')
        .setLabel('QUAL O NOVO BANNER?')
        .setRequired(true)
        .setStyle(1)
        
       modal.addComponents(new ActionRowBuilder().addComponents(aaaa))
       
       return interaction.showModal(modal);
    }
    
    if (interaction.isButton() && interaction.customId.endsWith("alt_thumb")) {
       const modal = new ModalBuilder()
        .setCustomId('modal_thumb')
        .setTitle('Alterar Thumbnail')
        
       const aaaa = new TextInputBuilder()
        .setCustomId('novo')
        .setLabel('QUAL A NOVA THUMBNAIL?')
        .setRequired(true)
        .setStyle(1)
        
       modal.addComponents(new ActionRowBuilder().addComponents(aaaa))
       
       return interaction.showModal(modal);
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("modal_titulo")) {
       const novo = interaction.fields.getTextInputValue('novo')
       
       db.set(`titulo`, novo)
       interaction.reply({ content: "✅ | Titulo da embed alterado com sucesso!", ephemeral: true })
       attembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("modal_color")) {
       const novo = interaction.fields.getTextInputValue('novo')
       
       const hex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/
       
       if (hex.test(novo)) {
         db.set(`color`, novo)
         interaction.reply({ content: "✅ | Cor da embed alterado com sucesso!", ephemeral: true })
       } else {
         interaction.reply({ content: ":x: | Você inseriu uma cor HEX inválida.", ephemeral: true })
       }
       
       attembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("modal_banner")) {
       const novo = interaction.fields.getTextInputValue('novo')
       
       const url = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
       
       if (url.test(novo)) {
         db.set(`banner`, novo)
         interaction.reply({ content: "✅ | Banner da embed alterado com sucesso!", ephemeral: true })
       } else {
         interaction.reply({ content: ":x: | Você inseriu um banner inválido.", ephemeral: true })
       }
       
       attembed()
    }
    
    if (interaction.isModalSubmit() && interaction.customId.endsWith("modal_thumb")) {
       const novo = interaction.fields.getTextInputValue('novo')
       
       const url = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
       
       if (url.test(novo)) {
         db.set(`thumb`, novo)
         interaction.reply({ content: "✅ | Thumbnail da embed alterado com sucesso!", ephemeral: true })
       } else {
         interaction.reply({ content: ":x: | Você inseriu uma thumbnail inválido.", ephemeral: true })
       }
       
       attembed()
    }
    
    
    async function attembed() {
      const embed = new EmbedBuilder()
      .setTitle(`${config.get('configs.name') == null ? interaction.guild.name : config.get('configs.name')} | Personalizar Embed`)
      .setDescription(`**Título atual:** ${db.get('titulo') == null ? `\`Não configurado\`` : db.get('titulo')}\n\n📑 **| Descrição:** \n${db.get('desc') == null ? `\`Não configurado\`` : db.get('desc')}`)
      .setColor(config.get('color'))
      
     const row = new ActionRowBuilder()
      .addComponents(
         new ButtonBuilder()
          .setCustomId('alt_titulo')
          .setLabel('Alterar Título')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_desc')
          .setLabel('Alterar Descrição')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_cor')
          .setLabel('Alterar Cor')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_banner')
          .setLabel('Alterar Banner')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_thumb')
          .setLabel('Alterar Thumbnail')
          .setStyle(1)
      )
      
      interaction.message.edit({ embeds: [embed], components: [row] })
    }
  }
}