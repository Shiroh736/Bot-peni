const { ActivityType } = require('discord.js');
const colors = require("colors");

module.exports = {
    name: 'ready',
    run: async (client) => {
        console.log(`${colors.green(`${client.user.tag} Foi iniciado`)}\n${colors.green(`Peni Remake`)}`)
        let activities = [
           `Peni Remake`,
           `Em Desenvolvimento`,
        ]
        i = 0;
        setInterval(() => 
        client.user.setPresence({
            activities: [{ name: `${activities[i++ %activities.length]}`, type: ActivityType.Watching}],
            
        }), 4000);
    }
}
  