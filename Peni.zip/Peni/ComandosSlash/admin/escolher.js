const Discord = require("discord.js")



module.exports = {
    name: "escolher",
    description: "Fale duas coisas que eu escolherei uma das duas.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "escolha1",
            type: Discord.ApplicationCommandOptionType.String,
            description: "Qual vai ser a primeira escolha?",
            required: true,
        },
        {
            name: "escolha2",
            type: Discord.ApplicationCommandOptionType.String,
            description: "Qual deve ser a segunda escolha?",
            required: true,
        },
        {
            name: 'secreta',
            type: Discord.ApplicationCommandOptionType.String,
            description: "É uma pergunta secreta?",
            required: true,
            choices: [
                { name: `Sim`, value: 'verdade' },
                { name: `Não`, value: 'falso' }
            ]
        }
    ],

run: async (client, interaction) => {

    let choice1 = interaction.options.getString('escolha1')
    let choice2 = interaction.options.getString('escolha2')
    let msgsecreta = interaction.options.getString('secreta')

    const escolhas = [
        choice1,
        choice2,
        ];
      
        const randomIndex = Math.floor(Math.random() * escolhas.length);
        const escolhida = escolhas[randomIndex];


        let embed = new Discord.EmbedBuilder()
        .setTitle(`Eu escolhi..`)
        .setColor("#5865f2")
        .setDescription(`Eu acho que você deveria escolher a..\n||\`\`\`${escolhida}\`\`\`||`)

        if(msgsecreta === 'verdade') {
            interaction.reply({ embeds: [embed], ephemeral: true })
        } else if (msgsecreta === 'falso') {
            interaction.reply({ embeds: [embed], ephemeral: false })
        }
},
}