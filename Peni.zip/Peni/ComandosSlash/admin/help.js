const Discord = require("discord.js")


module.exports = {
  name: "ajuda", // Coloque o nome do comando
  description: "🎈 [utilidade] Painel de comandos do bot.", // Coloque a descrição do comando
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {

    let embed_painel = new Discord.EmbedBuilder()
    .setColor("Aqua")
    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynmiac: true }) })
    .setDescription(`<:lost_atendente:1090798208625692733> Olá ${interaction.user}, veja meus comandos interagindo com o painel abaixo: Caso encontrar algum comando que nao esteja no **ajuda** favor usar o /reportar-bug. `);

    let embed_utilidade = new Discord.EmbedBuilder()
    .setColor("Aqua")
    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynmiac: true }) })
    .setDescription(`Olá ${interaction.user}, veja meus comandos de **utilidade** abaixo:
    
    • /ajuda (ver os comandos do bot)
    • /ping (ver ping do bot)
    • /clear (limpar mensagens de um chat)
    • /avatar (ver avatar de um membro)
    • /say (fazer o bot falar em embed)
    • /banner (ver banner de um membro)
    • /rename-server (renomear nome do server)
    • /emoji-info (informações do emoji)
    • /addemoji (adicionar um emoji)
    • /uptime (ver tempo que bot ta online)
    • /webhook-create (criar uma webhook)
    • /webhook-msg (mandar mensagem usando webhook)
    • /apoiadores (ver os apoiadores do bot)
    • /limpardm (bot limapara sua dm com ele)
    • /botinfo (informações do bot)
    • /event (vc criar um evento)
    • /role-info (informações de um cargo)
    • /player (ver um player minegraft original)
    • /enquete (criar uma enquete)
    • /dm (enviar uma mensagem no privado de um user)
    • /sorteio (fazer um sorteio com regras e premio)
	• /sugerir (fazer uma sugestão para a peni)
	• /contador (contar tanto de características tem um texto)`);

    let embed_diversao = new Discord.EmbedBuilder()
    .setColor("Aqua")
    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynmiac: true }) })
    .setDescription(`Olá ${interaction.user}, veja meus comandos de **diversão** abaixo:
    
    • /kiss (beijar alguém)
    • /cat (mostrar um membro foto de gato)
    • /tabuada (respostas tabuada)
    • /beleza (avaliar a beleze de um member)
    • /dado (jogar dado de 1 a 6)
    • /ppt (jogo pedra, papel, tesoura)
    • /slap (dar um tapa em um membro)
    • /roleta (rodar uma roleta russa)
    • /hug (abraçar algué)
    • /anime (mostra alguns animes)
    • /jogos (varios jogos do gamecord)
    • /escolher (fazer uma escolha)
	• /cafune (fazer carinho em alguém)
	• /dado2 (rolar dados 2)`);

    let embed_adm = new Discord.EmbedBuilder()
    .setColor("Aqua")
    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynmiac: true }) })
    .setDescription(`Olá ${interaction.user}, veja meus comandos de **administração** abaixo:
    
    • /ban (banir um determinado usuario)
    • /unban (desbanir um usuário)
    • /lock (trancar um canal)
    • /unlock (destrancar um canal)
    • /lista-banimentos (ver todos banidos do servidor)
    • /kick (expulsar alguem do servidor)
    • /slowmode (ativar modo lento do canal)
    • /serverinfo (informações do servidor)
    • /userinfo (informações do user)
    • /report (reportar um bug para o dev)
    • /deletarcanal (deletar um canal)
    • /mover-member (mover um membro da call)`);
    
    let embed_economia = new Discord.EmbedBuilder()
    .setColor("Aqua")
    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynmiac: true }) })
    .setDescription(`Olá ${interaction.user}, veja meus comandos de **economia** abaixo:
    
    • /rank (ver o rank de moedas quem estar em primeiro)
	• /daily (você pegar moedas todo dia)
    • /trabalhar (voce trabalhar para ganhar moedas)
	• /shop (você comprar alguma coisa na loja)
    • /carteira (carteira você ver seu saldo)
	• /inventário (ver as coisas que você tem no inventário)`);


    let painel = new Discord.ActionRowBuilder().addComponents(
        new Discord.SelectMenuBuilder()
            .setCustomId("painel_help")
            .setPlaceholder("Clique aqui!")
            .addOptions(
                {
                    label: "Painel",
                    //description: "",
                    emoji: "📖",
                    value: "painel"
                },
                {
                    label: "Utilidade",
                    description: "Veja meus comandos de utilidade.",
                    emoji: "🛠️",
                    value: "utilidade"
                },
                {
                    label: "Diversão",
                    description: "Veja meus comandos de diversão.",
                    emoji: "⭐",
                    value: "diversao"
                },
                {
                    label: "Administração",
                    description: "Veja meus comandos de administração.",
                    emoji: "👮",
                    value: "adm"
                },
                {
                    label: "economia",
                    description: "Veja meus comandos de economia.",
                    emoji: "💰",
                    value: "economia"
                }
            )
    )

    interaction.reply({ embeds: [embed_painel], components: [painel], ephemeral: true }).then( () => {
        interaction.channel.createMessageComponentCollector().on("collect", (c) => {
            let valor = c.values[0];

            if (valor === "painel") {
                c.deferUpdate()
                interaction.editReply({ embeds: [embed_painel] })
            } else if (valor === "utilidade") {
                c.deferUpdate()
                interaction.editReply({ embeds: [embed_utilidade] })
            } else if (valor === "diversao") {
                c.deferUpdate()
                interaction.editReply({ embeds: [embed_diversao] })
            } else if (valor === "adm") {
                c.deferUpdate()
                interaction.editReply({ embeds: [embed_adm] })
            } else if (valor === "economia") {
                c.deferUpdate()
                interaction.editReply({ embeds: [embed_economia] })
            }
        })
    })
  }
}