const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder } = require("discord.js");
const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./DatabaseJson/ConfigsEmbed.json" });
const config = new JsonDatabase({ databasePath: "./config.json" });

module.exports = {
  name: "config",
  description: "Configure o BOT e os Canais",
  
  run: async(client, interaction) => {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: ":x: | Você não possui permissão para utilizar esse comando.", ephemeral: true })
    
    
    const embed = new EmbedBuilder() 
     .setTitle(`${config.get('configs.name') == null ? interaction.guild.name : config.get('configs.name')} | Configurações`)
     .setDescription(`Nome do BOT: ${client.user.username}\nAvatar do BOT: [Abrir Avatar](${client.user.displayAvatarURL()})\nCor padrão: ${config.get(`configs.corbot`) == null ? `\`Não definido\`` : config.get(`configs.corbot`)}\nCanal de Boas Vindas: ${interaction.guild.channels.cache.get(config.get(`canais.boas_vinda`)) || "\`Não configurado\`"}`)
     .setColor(config.get('color'))
     
    const row = new ActionRowBuilder()
     .addComponents(
       new ButtonBuilder()
        .setCustomId('alt_nome')
        .setLabel('Alterar Nome')
        .setStyle(1),
       new ButtonBuilder()
        .setCustomId('alt_avatar')
        .setLabel('Alterar Avatar')
        .setStyle(1),
       new ButtonBuilder()
        .setCustomId('alt_color_bot')
        .setLabel('Alterar Cor')
        .setStyle(1),
       new ButtonBuilder()
        .setCustomId('alt_canal')
        .setLabel('Alterar Canal')
        .setStyle(1)
     )
     
     interaction.reply({ embeds: [embed], components: [row] }).then(msg => {
       
       const filter = i => i.user.id === interaction.user.id;
       const collector = msg.createMessageComponentCollector({ filter });
       
       collector.on('collect', interaction2 => {
          
          if (interaction2.customId == 'alt_nome') {
            const modal = new ModalBuilder()
             .setCustomId('nome_modal')
             .setTitle('Alterar Nome')
             
            const novo = new TextInputBuilder()
             .setCustomId('novo')
             .setLabel('QUAL NOVO NOME?')
             .setRequired(true)
             .setStyle(1)
             
            modal.addComponents(new ActionRowBuilder().addComponents(novo))
            
            interaction2.showModal(modal);
          }
          
          if (interaction2.customId == 'alt_avatar') {
            const modal = new ModalBuilder()
             .setCustomId('avatar_modal')
             .setTitle('Alterar Avatar')
             
            const novo = new TextInputBuilder()
             .setCustomId('novo')
             .setLabel('QUAL NOVO AVATAR?')
             .setRequired(true)
             .setStyle(1)
             
            modal.addComponents(new ActionRowBuilder().addComponents(novo))
            
            interaction2.showModal(modal);
          }
          
          if (interaction2.customId == 'alt_color_bot') {
            const modal = new ModalBuilder()
             .setCustomId('cor_modal')
             .setTitle('Alterar Cor')
             
            const novo = new TextInputBuilder()
             .setCustomId('novo')
             .setLabel('QUAL A NOVA COR?')
             .setRequired(true)
             .setStyle(1)
             
            modal.addComponents(new ActionRowBuilder().addComponents(novo))
            
            interaction2.showModal(modal);
          }
          
          if (interaction2.customId == 'alt_canal') {
            const modal = new ModalBuilder()
             .setCustomId('canal_modal')
             .setTitle('Alterar Canal')
             
            const novo = new TextInputBuilder()
             .setCustomId('novo')
             .setLabel('QUAL NOVO CANAL?')
             .setPlaceholder('Coloque o ID do canal')
             .setRequired(true)
             .setStyle(1)
             
            modal.addComponents(new ActionRowBuilder().addComponents(novo))
            
            interaction2.showModal(modal);
          }
          
       })
     })
  }
}