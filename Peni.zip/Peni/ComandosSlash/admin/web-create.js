const Discord = require("discord.js");

module.exports = {
  name: "webhook-create",
  description: "🎈 [Utilidade] Cria uma webhook",
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "canal",
      description: "Canal onde será criada a webhook",
      type: Discord.ApplicationCommandOptionType.Channel,
      required: true,
    },
    {
      name: "nome",
      description: "Nome da webhook",
      type: Discord.ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "avatar",
      description: "avatar da webhook",
      type: Discord.ApplicationCommandOptionType.Attachment,
      required: false,
    }
  ],

  run: async (client, interaction, args) => {
    try {
      const channel = interaction.options.getChannel("canal");
      const nome = interaction.options.getString("nome");
      const avatar = interaction.options.getAttachment("avatar");
      if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageWebhooks)) {
        return interaction.reply({ content: `Você não tem permissão para criar Webhooks!`, ephemeral: true });
      }

      if (!channel.permissionsFor(client.user).has(Discord.PermissionFlagsBits.ManageWebhooks)) {
        return interaction.reply({ content: `Eu não tenho permissão para criar Webhooks neste canal!`, ephemeral: true });
      }

      const webhook = await channel.createWebhook({
        name: nome,
        avatar: avatar ? avatar.url : undefined
      });

      const embed = new Discord.EmbedBuilder()
        .setColor("Random")
        .setTitle("Webhook Criada!")
        .setThumbnail(webhook.avatarURL())
        .setTimestamp()
        .addFields(
          { name: `Nome:`, value: `> ${webhook.name}` },
          { name: `Link:`, value: `> ${webhook.url}` },
          { name: `Canal:`, value: `> ${channel}` });

      interaction.reply({ embeds: [embed] });

    } catch (error) {
      console.error(error);
      interaction.reply({ content: "Ocorreu um erro ao criar a webhook!", ephemeral: true });
    }
  },
};
