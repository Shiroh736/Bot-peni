const Discord = require('discord.js');





module.exports = {
    name: 'ppt',
    description: '🎈 [Diversão] Joga pedra, papel, tesoura.',
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: 'jogada',
            description: 'Escolha sua jogada: pedra, papel ou tesoura.',
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
            choices: [
                {
                    name: 'Pedra',
                    value: 'pedra'
                },
                {
                    name: 'Papel',
                    value: 'papel'
                },
                {
                    name: 'Tesoura',
                    value: 'tesoura'
                }
            ]
        }
    ],
    run: async (client, interaction, args) => {

        const jogada = interaction.options.getString('jogada');
        const escolhas = ['pedra', 'papel', 'tesoura'];

        if (!escolhas.includes(jogada)) {
            return interaction.reply('Escolha inválida. Por favor, escolha pedra, papel ou tesoura.');
        }

        const escolhaBot = escolhas[Math.floor(Math.random() * escolhas.length)];

        let resultado;

        if (jogada === escolhaBot) {
            resultado = 'Empate!';
        } else if (
            (jogada === 'pedra' && escolhaBot === 'tesoura') ||
            (jogada === 'papel' && escolhaBot === 'pedra') ||
            (jogada === 'tesoura' && escolhaBot === 'papel')
        ) {
            resultado = 'Você venceu!';
        } else {
            resultado = 'Eu venci!';
        }

        const embed = new Discord.EmbedBuilder()
        .setColor('#f54eea')
        .setTitle('Pedra Papel Tesoura')
        .addFields(
            {name: 'Sua Jogada', value: `${jogada}`},
            {name: 'Minha Jogada', value: `${escolhaBot}`},
            {name: 'Resultado', value: `${resultado}`}
        );

        return interaction.reply({ embeds: [embed] });
    },
};