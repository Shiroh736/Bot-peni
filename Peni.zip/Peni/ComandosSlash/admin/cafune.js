const Discord = require('discord.js')

module.exports = {

    name: "cafuné",

    description: "🎈 [Diversão] esta imagem é tão fofinha! Vamos fazer cafuné nela!!",

    type: Discord.ApplicationCommandType.ChatInput,

    options: [

        {

            name: "usuário",

            description: "Mencione um usuário",

            type: Discord.ApplicationCommandOptionType.User, //nicko_ofc

            required: true,

        }

    ],

    run: async (client, interaction, args) => {



        let user = interaction.options.getUser("usuário")



        var lista1 = [

            'https://imgur.com/eFEgUMl.gif',

            'https://imgur.com/MMbBNhy.gif',

            'https://imgur.com/O5sDPN6.gif',

            'https://imgur.com/EhCdAue.gif',

            'https://imgur.com/qJzGLP5.gif'

        ];



        var lista2 = [

            'https://rrp-production.loritta.website/img/20be7326554c534e1898ac2543dced39dc036e17.gif',

            'https://rrp-production.loritta.website/img/72f21b39cacbb2702c461958d6e9fb599a11809a.gif',

            'https://rrp-production.loritta.website/img/e97de066504a44aa7d1563bbed9404b34f38c04c.gif',

            'https://rrp-production.loritta.website/img/51b6f4c8cf8d32b2ded7b4617cf2be00d25e3994.gif',

            'https://rrp-production.loritta.website/img/97a6bc6994b8d37ef255c592aa8003fe956a350b.gif'

        ];



        var random1 = lista1[Math.floor(Math.random() * lista1.length)];

        var random2 = lista2[Math.floor(Math.random() * lista2.length)];



        const embed = new Discord.EmbedBuilder()

            .setDescription(`**${interaction.user} fez cafuné em ${user}!**`)

            .setImage(`${random1}`)

            .setColor("Random")



        const button = new Discord.ActionRowBuilder()

            .addComponents(

                new Discord.ButtonBuilder()

                    .setCustomId('1')

                    .setLabel('Retribuir')

                    .setStyle(Discord.ButtonStyle.Primary)

                    .setDisabled(false)



            )



        const embed1 = new Discord.EmbedBuilder()

            .setDescription(`**${user} fez cafuné em ${interaction.user}!**`)

            .setColor("Random")

            .setImage(`${random2}`)



        interaction.reply({ embeds: [embed], components: [button] }).then(() => {

            const filter = i => i.customId === '1' && i.user.id === user.id;

            const collector = interaction.channel.createMessageComponentCollector({ filter, max: 1 });



            collector.on('collect', async i => {

                if (i.customId === '1') {

                    i.reply({ embeds: [embed1] })

                }

            });



            collector.on("end", () => {

                interaction.editReply({

                    components: [

                        new Discord.ActionRowBuilder()

                            .addComponents(

                                new Discord.ButtonBuilder()

                                    .setCustomId('1')

                                    .setLabel('Retribuir')

                                    .setStyle(Discord.ButtonStyle.Primary)

                                    .setDisabled(true)



                            )

                    ]

                })

            })

        })

    }

}

