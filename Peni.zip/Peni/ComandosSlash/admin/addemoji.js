const { PermissionFlagsBits, ApplicationCommandOptionType, parseEmoji } = require("discord.js");



module.exports = {

    name: "addemoji",

    description: "🎈 [Utilidade] Add emojis emojisall em seu server!",

    default_member_permissions: [PermissionFlagsBits.Administrator],

    options: [

        {

            name: "emojis",

            description: "Add emojis simultaneamente em seu server",

            type: ApplicationCommandOptionType.String,

            required: true,

        },

    ],



    run: async (client, interaction) => {

        await interaction.deferReply()



        const Emojis = interaction.options.getString("emojis");

        const emojiRegex = /<a?:(.*?):(\d+)>/g;

        const emojiMatches = Emojis.match(emojiRegex);



        if (!emojiMatches) {

            return interaction.editReply({ content: "No valid emojis found in your input.", ephemeral: true });

        }



        const addedEmojis = [];



        for (const emojiString of emojiMatches) {

            const parsed = parseEmoji(emojiString);

            const link = `https://cdn.discordapp.com/emojis/${parsed.id}${parsed.animated ? '.gif' : '.png'}`;



            try {

                const emoji = await interaction.guild.emojis.create({ attachment: link, name: parsed.name });

                addedEmojis.push(emoji);

            } catch (error) {

                console.error(error);

                return interaction.editReply({ content: `Error adding emoji limite de emojis server ${parsed.name}.`, ephemeral: true });

            }

        }



        if (addedEmojis.length > 1) {

            const addedEmojiNames = addedEmojis.map(emoji => `${emoji}`).join(" ");

            await interaction.editReply({ content: `<a:verificadoanim:1143276457670492300> Emojis successfully adicionados!!!: ${addedEmojiNames}`, });

        } else if (addedEmojis.length === 1) {

            await interaction.editReply({ content: `${addedEmojis} | <a:verificadoanim:1143276457670492300> Emoji successfully adicionado!`, });

        }

    }

}