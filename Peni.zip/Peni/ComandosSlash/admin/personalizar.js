const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, PermissionFlagsBits } = require("discord.js");
const { JsonDatabase, } = require("wio.db");
const db = new JsonDatabase({ databasePath: "./DatabaseJson/ConfigsEmbed.json" });
const config = new JsonDatabase({ databasePath: "./config.json" });

module.exports = {
   name: "personalizar",
   description: "Personalizar a embed de boas vindas",
   
   run: async(client, interaction) => {
     if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: ":x: | Você não possui permissão para utilizar esse comando.", ephemeral: true })
     
     
     const embed = new EmbedBuilder()
      .setTitle(`${config.get('configs.name') == null ? interaction.guild.name : config.get('configs.name')} | Personalizar Embed`)
      .setDescription(`**Título atual:** ${db.get('titulo') == null ? `\`Não configurado\`` : db.get('titulo')}\n\n📑 **| Descrição:** \n${db.get('desc') == null ? `\`Não configurado\`` : db.get('desc')}`)
      .setColor(config.get('color'))
      
     const row = new ActionRowBuilder()
      .addComponents(
         new ButtonBuilder()
          .setCustomId('alt_titulo')
          .setLabel('Alterar Título')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_desc')
          .setLabel('Alterar Descrição')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_cor')
          .setLabel('Alterar Cor')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_banner')
          .setLabel('Alterar Banner')
          .setStyle(1),
         new ButtonBuilder()
          .setCustomId('alt_thumb')
          .setLabel('Alterar Thumbnail')
          .setStyle(1)
      )
     
     await interaction.reply({ embeds: [embed], components: [row] })
   }
}