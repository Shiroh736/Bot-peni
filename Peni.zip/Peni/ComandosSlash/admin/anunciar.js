const { TextInputStyle } = require(`discord.js`)

const { InteractionType } = require(`discord.js`)

const Discord = require(`discord.js`)

module.exports = {
  name: 'anunciar',
  description: '🎈 [Utilidades] Faça um anúncio',
  type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "chat",
      description: "Mencione um canal.",
      type: Discord.ApplicationCommandOptionType.Channel,
      channelTypes: [
        Discord.ChannelType.GuildText,
      ],
      required: true,
    },
    {
          name: "menção",
          type: Discord.ApplicationCommandOptionType.Role,
          description: "Selecione uma cargo para a menção.",
          required: false
      }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.ManageMessages))
      return interaction.reply({content: `**<a:no:1111133075448016977> - Você sabe que não tem permição para usar este comando, e mesmo assim fica tentando!**`, ephemeral: true,
      })
      const BronxMo = interaction.options.getRole('menção') || '';

    let BronxM = new Discord.ModalBuilder()
      .setCustomId(`BronxE`)
      .setTitle(`🔰 - Painel Anuncio`)
    let BronxT = new Discord.TextInputBuilder()
      .setCustomId(`BronxT`)
      .setLabel(`🚀 - Título da Embed`)
      .setPlaceholder(`Digite o título da Embed.`)
      .setStyle(TextInputStyle.Short)
    let BronxD = new Discord.TextInputBuilder()
      .setCustomId(`BronxD`)
      .setLabel(`📄 - Descrição da Embed`)
      .setPlaceholder(`Digite a descrição da Embed`)
      .setStyle(TextInputStyle.Paragraph)
    let Bronx1Act = new Discord.ActionRowBuilder()
      .addComponents(BronxT);
    let Bronx2Act = new Discord.ActionRowBuilder()
      .addComponents(BronxD);
    let chat = interaction.options.getChannel("chat")
    BronxM.addComponents(Bronx1Act, Bronx2Act)
    await interaction.showModal(BronxM);
    client.once(`interactionCreate`, async interaction => {
      if (!interaction.isModalSubmit()) return;
      if (interaction.customId === `BronxE`) {
        let BronxD = interaction.fields.getTextInputValue(`BronxD`);
        let BronxT = interaction.fields.getTextInputValue(`BronxT`);
        let BronxMd = new Discord.EmbedBuilder()
          .setTitle(`${BronxT}`)
          .setDescription(`${BronxD}`)
          .setColor("#5662F6")
          .setFooter(({ text: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) }))
          interaction.reply({ content: "**Estou enviando seu anúncio aguarde <a:dverifygreen:1100550210427568158> " }).then( () => {
            setTimeout( () => {
                chat.send(`${BronxMo}`),
                chat.send({ embeds: [BronxMd] })
                interaction.editReply({ content: `**<:lost:1083553017367900332> - ${interaction.user},Sua embed foi enviada com sucesso no canal ${chat}**`, ephemeral: true})
            }, 3000)
        })
    }
    })
}
};