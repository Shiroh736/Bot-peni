const Discord = require('discord.js')

module.exports = {
    name: "apoiadores",
    description: "🎈 ｢Utilidades｣ Veja os Apoiadores e boosters da peni",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {

        
        const embed = new Discord.EmbedBuilder()
        .setTitle("Lista Apoiadores")
        .setColor('#0000FF')
        .setDescription(`
>  **Olá ${interaction.user}, aqui esta uma lista de boosters e apoiador do servidor da Peni.**

 | [Ver lista](https://www.websitepeni.shop/Premium)
 | [Convite servidor](https://discord.gg/q4Z4ZvmJd8)`)
        .setTimestamp()

        interaction.reply({ embeds: [embed] })
    }
}
