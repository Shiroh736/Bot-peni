const { TextInputStyle } = require('discord.js')



const { InteractionType } = require('discord.js')

const Discord = require('discord.js')

module.exports = {
    name: 'reportar-bug',
    description: '﹝Utilidade﹞Reporte O Bug Para O Meu Desenvolvedor❗',
    type: Discord.ApplicationCommandType.ChatInput,
    
    run: async(client, interaction) => {

        const modal = new Discord.ModalBuilder()
        .setCustomId('BUGs')
        .setTitle('REPORT - BUG')
        
        const BUG = new Discord.TextInputBuilder()
        .setCustomId('BUG')
        .setLabel('Qual e o bug encontrado?')
        // Paragraph Significa Que Suporta Varias Linhas De Texto❗❗
        .setStyle(TextInputStyle.Paragraph)

		const firstActionRow = new Discord.ActionRowBuilder().addComponents(BUG);

        modal.addComponents(firstActionRow)

        await interaction.showModal(modal);

        client.on('interactionCreate', async interaction => {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'BUGs') {

	    const REPORTADO = interaction.fields.getTextInputValue('BUG');

        let log = client.channels.cache.get('1105823316243124264') //ID DO CANAL PARA REPORTS

        interaction.reply({
            content: `<:lost:1083553017367900332> | BUG REPORTADO COM SUCESSO❗`, ephemeral: true
        })

       
        log.send({
            embeds: [new Discord.EmbedBuilder()
                .setColor('FF0000')
                .setTitle(`<a:LosT_redsirene:1107756998851842139> - Novo BUG Reportado!`)
                .setDescription(`SERVIDOR: \`${interaction.guild.name}\`
                 USUÁRIO: \`${interaction.user.tag}\`
                 BUG REPORTADO: \`${REPORTADO}\``)
            ]
        })

    }

});


    }
}