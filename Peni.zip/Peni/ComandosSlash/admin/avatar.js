const { ApplicationCommandOptionType, ApplicationCommandType, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  name: "avatar", //Nome do comando
  description: "[ Utilidades ] Mostra o avatar de alguém ou o seu.", // Descrição do comando
  type: ApplicationCommandType.ChatInput, // Tipo do comando
  options: [
    {
      name: 'user', // Nome da opção
      description: 'O usuário que deseja ver o avatar.', // Descrição da opção
      type: ApplicationCommandOptionType.User, // Tipo da opção
      required: false, // Obrigatório? Não = false Sim = True
    }
  ],

  run: async (client, interaction) => {
        let user = interaction.options.getUser('user');
        if (!user) user = interaction.user;

        const replyEmbed = new EmbedBuilder()
            .setColor(0xafeeee)
            .setTitle(`📸 | ${user.username}`)
            .setImage(user.avatarURL())
            .setTimestamp()
            .setFooter({text: `Solicitado por ${interaction.user.tag}`, iconURL: interaction.user.avatarURL({dynamic: true, size: 2048})});

        const viewer = new ButtonBuilder()
            .setLabel('Abrir foto')
            .setURL(user.avatarURL({dynamic: true, size: 2048}))
            .setStyle(ButtonStyle.Link);

        const row = new ActionRowBuilder()
            .addComponents(viewer);

        await interaction.reply({embeds: [replyEmbed], components: [row]});

      }
}