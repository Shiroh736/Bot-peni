const Discord = require("discord.js")

module.exports = {
    name: "sugerir", // Coloque o nome do comando
    description: "Faça sua sugestão.", // Coloque a descrição do comando
    type: Discord.ApplicationCommandType.ChatInput,
    options: [
        {
            name: "sugestão",
            description: "Escreva alguma sugestão.",
            type: Discord.ApplicationCommandOptionType.String,
            required: true,
        }
    ],
    run: async (client, interaction) => {
        const user = client.users.cache.get('1083914942572396656')
        if (!user ) return interaction.reply(`Olá ${interaction.user}, não foi possível mandar a sugestão pois o id não foi configurado`)

        let sugestao = interaction.options.getString("sugestão");
        let embed = new Discord.EmbedBuilder()
        .setColor("Random")
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setTitle("Nova sugestão!")
        .setDescription(`**Sugestão de ${interaction.user}:**\n${sugestao}`);

        user.send({ embeds: [embed] }).then(() => {
            interaction.reply({ content: `Olá ${interaction.user}, sua sugestão foi enviada com sucesso para dev.` })
        }).catch(() => {
            interaction.reply({ content: `Ops ${interaction.user}, algo deu errado!` })
        })
    }
}