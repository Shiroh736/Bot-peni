const d = require("discord.js");

module.exports = {
  name: "contador",
  description: "Conta palavras, emojis, espaços, quebras de linha, letras maiúsculas e minúsculas em um texto.",
  type: d.ApplicationCommandType.ChatInput,
  options: [
    {
      name: "texto",
      description: "Digite o texto que deseja contar.",
      type: d.ApplicationCommandOptionType.String,
      required: true,
    },
  ],

  run: async (client, interaction) => {

    const texto = interaction.options.getString("texto");

    const wordCount = texto
      .split(/\s+/)
      .filter((word) => word.length > 0).length;

    const emojiCount = ( texto.match( /<a?:\w+:\d+>|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\u2600-\u27FF]/g ) || [] ).length;
    
    const spaceCount = texto.split("").filter((char) => /\s/.test(char)).length;
    
    const uppercaseCount = texto
      .split("")
      .filter((char) => /[A-Z]/.test(char)).length;
    
    const lowercaseCount = texto
      .split("")
      .filter((char) => /[a-z]/.test(char)).length;
    
    const charCount = texto.length;
    
    const specialCharCount = ( texto.match(/[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/g) || [] ).length;
    
    const numberCount = (texto.match(/\d/g) || []).length;
    
    const linkCount = (texto.match(/https?:\/\/\S+/gi) || []).length;

    const embed = new d.EmbedBuilder()
      .setDescription(`> **texto:**  \n\`\`\`${texto}\`\`\``)
      .addFields(
        { name: "Palavras", value: `${wordCount}`, inline: true },
        { name: "Características", value: `${charCount}`, inline: true },
        { name: "Emojis", value: `${emojiCount}`, inline: true },
        { name: "Espaços", value: `${spaceCount}`, inline: true },
        { name: "Maiusculas", value: `${uppercaseCount}`, inline: true },
        { name: "Minusculas", value: `${lowercaseCount}`, inline: true },
        { name: "características especiais", value: `${specialCharCount}`, inline: true },
        { name: "numeros", value: `${numberCount}`, inline: true },
        { name: "links", value: `${linkCount}`, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
