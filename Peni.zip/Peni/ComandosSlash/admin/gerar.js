const Discord = require("discord.js");

 module.exports = {
    name: "gerarsenha",
    description: " 🎈 [ADMIN] Gera uma senha aleatória e segura.",
    options: [

        {
            name: "tamanho",
            type: Discord.ApplicationCommandOptionType.Integer,
            description: "O tamanho da senha (entre 8 à 64 caracteres)",
            required: true
        }
    ],
        run: async (client, interaction) => {
          
    const tamanho = interaction.options.getInteger('tamanho');
    if (tamanho < 8 || tamanho > 64) {
      return interaction.reply({ content: 'O tamanho da senha deve estar entre 8 e 64 caracteres.', ephemeral: true });
    }
    const senha = [...Array(tamanho)].map(i => (~~(Math.random() * 36)).toString(36)).join('');
    
   return  interaction.reply({ content: `Sua nova senha é: \`${senha}\``, ephemeral: true });
  },
};
